export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyAQc5EF8wddyS4c1MRQJRC1xHCIFV1Gk0o",
    authDomain: "restrestcar.firebaseapp.com",
    databaseURL: "https://restrestcar.firebaseio.com",
    projectId: "restrestcar",
    storageBucket: "restrestcar.appspot.com",
    messagingSenderId: "252999148152"
}